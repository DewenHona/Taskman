# Flutter Minimal UI

Login and Signup screens.

## Design Credit - https://dribbble.com/shots/5239966-Daily-UI-001

## How do I make this - https://youtu.be/PJU6HFWOM6I
